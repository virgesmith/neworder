
""" pyramid plots """

import matplotlib.pyplot as plt

# see https://stackoverflow.com/questions/27694221/using-python-libraries-to-plot-two-horizontal-bar-charts-sharing-same-y-axis
def plot(ages, males, females):

  xmax = 6000 #max(max(males), max(females))

  fig, axes = plt.subplots(ncols=2, sharey=True)
  plt.gca().set_ylim([min(ages),max(ages)+1])
  fig.suptitle("2011")
  axes[0].set(title='Males')
  axes[0].set(xlim=[0, xmax])
  axes[1].set(title='Females')
  axes[1].set(xlim=[0, xmax])
  axes[0].yaxis.tick_right()
  #axes[1].set(yticks=ages)
  axes[0].invert_xaxis()
  for ax in axes.flat:
    ax.margins(0.03)
  fig.tight_layout()
  fig.subplots_adjust(wspace=0.125)
  mbar = axes[0].barh(ages, males, align='center', color='blue')
  fbar = axes[1].barh(ages, females, align='center', color='red')
  plt.pause(0.1)
  plt.ion()
  return fig, axes, mbar, fbar

def update(title, fig, axes, mbar, fbar, ages, males, females):
  mbar.remove()
  mbar = axes[0].barh(ages, males, align='center', color='blue')
  fbar.remove()
  fbar = axes[1].barh(ages, females, align='center', color='red')
  fig.suptitle(title)
  plt.pause(0.1)
  return mbar, fbar
