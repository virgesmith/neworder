
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from neworder import Model, LinearTimeline, StateGrid, Edge, MonteCarlo, as_np

N = 100
ROCK = 0
GRASS = 1
LAKE = 2

class Evolution(Model):

  def __init__(self) -> None:
    super().__init__(LinearTimeline(0.0, 1.0), MonteCarlo.nondeterministic_stream)
    self.world = StateGrid(np.full((N, N), ROCK, dtype=int), edge=Edge.CONSTRAIN)

    # generate
    moves = ((-1, 0), (0, -1), (1, 0), (0, 1))
    stack = [(N//2, N//2)]
    # for _ in range(20):
    while stack:
      p = stack.pop()
      self.world[p] = GRASS
      for _ in range(2):
        pnew = self.world.shift(p, moves[self.mc.raw() % 4])
        if self.world[pnew] == ROCK:
          stack.append(pnew)

    for _ in range(5):
      stack = [(self.mc.raw() % self.world.state.shape[0], self.mc.raw() % self.world.state.shape[1])]
      while stack:
        p = stack.pop()
        self.world[p] = LAKE
        for _ in range(2):
          pnew = self.world.shift(p, moves[self.mc.raw() % 4])
          if self.world[pnew] == GRASS:
            stack.append(pnew)

m = Evolution()

fig, ax = plt.subplots(figsize=(10, 10))
ax.imshow(m.world.state, cmap=ListedColormap(["#404040", "green", "blue"]))
plt.tight_layout()
plt.show()
# print(m.world.state)

